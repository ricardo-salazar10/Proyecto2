//
//  MyCollectionViewCell.swift
//  Proyecto2
//
//  Created by:
//  - Salazar Olivares Ricardo
//  - Yonatan Martín Galicia Serrano
//  on 14/11/24.
//

import UIKit

class MyCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var productImageCell: UIImageView!
    @IBOutlet weak var productNameCell: UILabel!
}
